# ng-demo-book
book inventory demonstration with API call option
