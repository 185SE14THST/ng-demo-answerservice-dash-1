project.value('metrics',{
     "recievedCalls" : 52,
     "totalMinutes" : 850,
     "avgCallTime" : 13.9,
     "avgCallsPerDay" : 257,
     "overageMinutes" : 230,
     "totalCosts" : 785.94,
});
