/* Summary:         Application definition
*
* Descriptions:     This program will create a dynamic AngularJS Application
*
* Programmer:       185SE14THST
*
* Date:             2016-09-16
*/
var project = angular.module('project', ['ngRoute', 'ngResource']);
